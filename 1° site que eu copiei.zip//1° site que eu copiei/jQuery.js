$('.nav a[href^="#"]').on('click', function (e) {
		e.preventdefault ();
		var id = $ (this).attr('href'),
		target0ffset = $(id).offset().top;
		$('html, body').animate({
				scrollTop: target0ffset - 100
		}, 500);
});