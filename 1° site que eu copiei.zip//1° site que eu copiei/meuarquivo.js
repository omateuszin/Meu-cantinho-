var target_offset = $("#r").offset();
var target_top = target_offset.top;
$('html, body').animate({ scrollTop: 2000 }, 500000);
